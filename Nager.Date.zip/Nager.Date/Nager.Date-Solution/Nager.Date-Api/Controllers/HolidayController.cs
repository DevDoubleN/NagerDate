﻿using Microsoft.AspNetCore.Mvc;
using Nager.Date_Api.Application.Services.DTOs;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Dynamic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Nager.Date_Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HolidayController : ControllerBase
    {
        /// <summary>
        /// Get the public holidays from the given year and country.
        /// </summary>
        /// <param name="year">Year</param>
        /// <param name="country">Country</param>
        /// <returns>A list of holidays from the year and the country.</returns>
        [HttpGet]
        public async Task<IActionResult> FindHolydays(int year, string country)
        {
            if (year > 999 && year < 10000)
            {
                if (country.Length == 2)
                {
                    try
                    {
                        var request = new HttpRequestMessage(HttpMethod.Get, "https://date.nager.at/api/v3/PublicHolidays" + $"/{year}/{country}");
                        var response = new GenericResponse<HolidayDTO>();

                        using (var client = new HttpClient())
                        {
                            var responseDateNager = await client.SendAsync(request);
                            var content = await responseDateNager.Content.ReadAsStringAsync();
                            var obj = JsonConvert.DeserializeObject<List<HolidayDTO>>(content);

                            if (responseDateNager.IsSuccessStatusCode)
                            {
                                response.StatusCode = responseDateNager.StatusCode;
                                response.ListResponse = obj;
                            }
                            else
                            {
                                response.StatusCode = responseDateNager.StatusCode;
                                response.ErrorReturn = JsonConvert.DeserializeObject<ExpandoObject>(content);
                            }
                        }

                        return Ok(response);
                    }
                    catch
                    {
                        return NoContent();
                    }
                }
            }

            return NoContent();
        }
    }
}
