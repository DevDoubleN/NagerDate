﻿namespace Nager.Date_Api.Application.Services.Enums
{
    public enum Types
    {
        Public,
        Bank,
        School,
        Authorities,
        Optional,
        Observance
    }
}
