﻿using System;
using System.Text.Json.Serialization;
using Nager.Date_Api.Application.Services.Enums;

namespace Nager.Date_Api.Application.Services.DTOs
{
    public class HolidayDTO
    {
        [JsonPropertyName("date")]
        public DateTime Date { get; set; }
        [JsonPropertyName("localName")]
        public string LocalName { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("countryCode")]
        public string CountryCode { get; set; }
        [JsonPropertyName("fixed")]
        public bool Fixed { get; set; }
        [JsonPropertyName("global")]
        public bool Global { get; set; }
        [JsonPropertyName("counties")]
        public string[]? Counties { get; set; }
        [JsonPropertyName("launchYear")]
        public int? LaunchYear { get; set; }
        [JsonPropertyName("types")]
        public string[] Type { get; set; }
    }
}
