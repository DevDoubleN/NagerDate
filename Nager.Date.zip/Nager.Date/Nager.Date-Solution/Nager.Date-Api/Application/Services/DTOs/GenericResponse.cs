﻿using System.Net;
using System.Dynamic;
using System.Collections.Generic;

namespace Nager.Date_Api.Application.Services.DTOs
{
    public class GenericResponse<T> where T : class
    {
        public HttpStatusCode StatusCode { get; set; }
        public T? DataResponse { get; set; }
        public List<T>? ListResponse { get; set; }
        public ExpandoObject? ErrorReturn { get; set; }
    }
}
