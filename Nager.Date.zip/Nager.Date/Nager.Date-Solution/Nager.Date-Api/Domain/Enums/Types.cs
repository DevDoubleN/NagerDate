﻿namespace Nager.Date_Api.Domain.Enums
{
    public enum Types
    {
        Public,
        Bank,
        School,
        Authorities,
        Optional,
        Observance
    }
}
